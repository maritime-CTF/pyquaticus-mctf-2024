IMPORTANT!!
If submitting to codalab your entry must follow the provided solution.py template the file name is REQUIRED to be 'solution.py' and have the same methods provided in the example.